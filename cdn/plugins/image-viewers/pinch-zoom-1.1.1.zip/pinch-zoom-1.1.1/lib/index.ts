import PinchZoom from './pinch-zoom';
export * from './pinch-zoom';
export { default } from './pinch-zoom';
customElements.define('pinch-zoom', PinchZoom);
