
<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author Shakir
 * @date ${date} - ${time}
 */
public interface ${name}
{

}